These tests are designed to be run from a subdirectory placed inside a
student's xv6 directory. e.g. `clone` these to `tests` in `xv6-public`, then:

```
$ cd tests
$ ./run-all
$ grep \*\*\* logs/latest.log
```
